# 🚀 Guia Completo: Subir Seu App no Vercel

## O Que é Vercel?
Vercel é uma plataforma **100% gratuita** que hospeda sites. Você sobe seu arquivo HTML e qualquer pessoa no mundo pode acessar via um link!

---

## PASSO 1: Preparar seus arquivos

### 1.1 Crie uma pasta no seu computador
```
Crie uma pasta chamada: vocabulario-app
```

### 1.2 Adicione o arquivo HTML
- Coloque o arquivo `vocabulary-app.html` dentro dessa pasta
- **Renomeie** para `index.html` (IMPORTANTE!)

**Por quê?** Vercel procura automaticamente por `index.html` como página inicial.

**Estrutura final:**
```
vocabulario-app/
└── index.html
```

---

## PASSO 2: Criar conta no GitHub (necessário para Vercel)

### 2.1 Acesse https://github.com
- Clique em **Sign up** (Criar conta)
- Preencha:
  - Email: seu_email@gmail.com
  - Password: uma senha forte
  - Username: seu_nome_de_usuario
- Clique **Create account**

### 2.2 Confirme seu email
- Você receberá um email de confirmação
- Clique no link dentro do email
- Pronto! Sua conta GitHub está ativa

---

## PASSO 3: Criar um Repositório no GitHub

### 3.1 Após fazer login no GitHub
- Clique no **+** (canto superior direito)
- Selecione **New repository**

### 3.2 Preencha as informações
```
Repository name: vocabulario-app
Description: Aprenda uma palavra nova todos os dias em múltiplos idiomas
Visibility: Public (para outros poderem acessar)
```

### 3.3 Clique em **Create repository**

### 3.4 Você verá uma tela com comandos
**NÃO feche essa página!** Você vai precisar desses comandos em breve.

---

## PASSO 4: Instalar Git no seu computador

### 4.1 Acesse https://git-scm.com/download
- Baixe a versão para seu sistema (Windows/Mac/Linux)
- Execute o instalador e siga os passos padrão

### 4.2 Abra o Terminal/Prompt de Comando
- **Windows:** Pressione `Win + R`, digite `cmd`, aperte Enter
- **Mac:** Cmd + Space, procure "Terminal", aperte Enter
- **Linux:** Abra o Terminal normalmente

---

## PASSO 5: Upload dos Arquivos para GitHub

### 5.1 No Terminal, navegue até sua pasta
```bash
cd caminho/para/vocabulario-app
```

**Exemplo para Windows:**
```bash
cd C:\Users\SeuNome\Desktop\vocabulario-app
```

**Exemplo para Mac/Linux:**
```bash
cd ~/Desktop/vocabulario-app
```

### 5.2 Execute estes comandos (um por um)

```bash
# 1. Inicie um repositório git local
git init

# 2. Configure seu nome (use o mesmo do GitHub)
git config --global user.name "Seu Nome"

# 3. Configure seu email
git config --global user.email "seu_email@gmail.com"

# 4. Adicione seus arquivos
git add .

# 5. Faça um "commit" (tirar foto do seu código)
git commit -m "Primeiro commit do app de vocabulário"

# 6. Renomeie a branch para main
git branch -M main

# 7. Adicione o repositório remoto (copie exatamente do GitHub)
git remote add origin https://github.com/SEU_USERNAME/vocabulario-app.git

# 8. Envie os arquivos para GitHub
git push -u origin main
```

### 5.3 Será solicitada sua senha
- Cole seu **username do GitHub**
- Cole sua **senha do GitHub**
- Aperte Enter

**✅ Pronto!** Seus arquivos estão no GitHub!

---

## PASSO 6: Conectar GitHub ao Vercel

### 6.1 Acesse https://vercel.com
- Clique em **Sign up** (Criar conta)

### 6.2 Escolha "Continue with GitHub"
- Uma janela abrirá pedindo para conectar
- Clique em **Authorize Vercel**

### 6.3 Você será redirecionado para Vercel
- Clique em **+ New Project**

### 6.4 Selecione seu repositório
- Procure por **vocabulario-app**
- Clique nele

### 6.5 Configure o projeto
- **Project Name:** vocabulario-app (já preenchido)
- **Framework:** Selecione "Other" (não precisa framework)
- Clique em **Deploy**

---

## PASSO 7: Espere o Deploy

Vercel começará a processar seu site:
- Você verá uma tela com "Building..."
- Isso leva **2-3 minutos**
- Quando terminar, verá "✅ Deployment successful"

---

## PASSO 8: Pegue o Link do Seu Site

### 8.1 Na página de sucesso
- Você verá algo como:
```
https://vocabulario-app-abc123.vercel.app
```

### 8.2 **Este é o link que você compartilha com seus amigos!** 🎉

---

## ✨ Pronto! Seu app está online!

Agora seus amigos podem:
1. Abrir o link em qualquer navegador
2. Clicar em "Adicionar à tela de início" (mobile)
3. Usar como um app real!

---

## 📱 Como seus amigos usam:

### No iPhone:
1. Abrem o link em Safari
2. Clicam o botão Compartilhar (↗️)
3. Selecionam "Adicionar à Tela de Início"
4. Pronto! Fica como app

### No Android:
1. Abrem o link em Chrome
2. Clicam os 3 pontos (⋮)
3. Selecionam "Instalar app"
4. Pronto! Fica como app

---

## 🔄 Atualizar o app no Vercel

Se você quiser fazer mudanças depois:

```bash
# Na sua pasta vocabulario-app:
git add .
git commit -m "Descrevendo a mudança"
git push
```

Vercel **automaticamente faz o deploy** da nova versão!

---

## 🆘 Dúvidas?

| Problema | Solução |
|----------|---------|
| **Git não funciona** | Reinicie o Terminal/CMD |
| **Senha não funciona** | Use "Personal Access Token" (GitHub → Settings → Developer settings) |
| **Build falha no Vercel** | Certifique-se que o arquivo se chama `index.html` |
| **Não vejo meu site** | Aguarde 5 minutos, depois recarregue a página |

---

## 🎯 Resumo Visual

```
1. Criar pasta com index.html
         ↓
2. Criar conta GitHub + repositório
         ↓
3. Fazer upload com Git
         ↓
4. Conectar GitHub ao Vercel
         ↓
5. Vercel faz deploy automático
         ↓
6. Link público criado!
         ↓
7. Compartilhar com amigos 🎉
```

---

## Links Úteis

- **Vercel:** https://vercel.com
- **GitHub:** https://github.com
- **Git Download:** https://git-scm.com
- **Documentação Vercel:** https://vercel.com/docs

**Boa sorte! 🚀**
